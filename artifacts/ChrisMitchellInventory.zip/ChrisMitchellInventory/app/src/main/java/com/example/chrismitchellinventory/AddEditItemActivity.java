package com.example.chrismitchellinventory;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class AddEditItemActivity extends AppCompatActivity {

    private TextView textTitle;
    private EditText editName;
    private EditText editQty;

    // On-screen SMS result (for screenshots)
    private TextView textSmsResult;

    private ItemRepository itemRepo;

    // Edit mode fields
    private boolean isEditMode = false;
    private long editItemId = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_add_edit_item);

        textTitle = findViewById(R.id.textAddEditTitle);
        editName = findViewById(R.id.editItemName);
        editQty = findViewById(R.id.editItemQty);
        textSmsResult = findViewById(R.id.textSmsResult);

        Button btnSave = findViewById(R.id.buttonSaveItem);
        Button btnCancel = findViewById(R.id.buttonCancelItem);

        itemRepo = new ItemRepository(this);

        // Determine mode from Intent extras
        String mode = getIntent().getStringExtra("mode");
        isEditMode = "edit".equals(mode);

        if (isEditMode) {
            textTitle.setText("Edit Item");
            editItemId = getIntent().getLongExtra("item_id", -1);

            // Pre-fill fields
            String name = getIntent().getStringExtra("name");
            int qty = getIntent().getIntExtra("qty", 0);

            if (name != null) editName.setText(name);
            editQty.setText(String.valueOf(qty));
        } else {
            textTitle.setText("Add Item");
        }

        // Clear status
        textSmsResult.setText("");

        btnSave.setOnClickListener(v -> onSave());
        btnCancel.setOnClickListener(v -> finish());
    }

    private void onSave() {
        String name = editName.getText().toString().trim();
        String qtyStr = editQty.getText().toString().trim();

        if (TextUtils.isEmpty(name)) {
            editName.setError("Item name required");
            return;
        }

        int qty = 0;
        if (!TextUtils.isEmpty(qtyStr)) {
            try {
                qty = Integer.parseInt(qtyStr);
            } catch (NumberFormatException e) {
                editQty.setError("Quantity must be a number");
                return;
            }
        }

        if (qty < 0) {
            editQty.setError("Quantity cannot be negative");
            return;
        }

        boolean savedOk;

        if (isEditMode) {
            if (editItemId <= 0) {
                editName.setError("Could not identify item to update");
                return;
            }

            int rows = itemRepo.updateItem(editItemId, name, qty);
            savedOk = rows > 0;
            if (!savedOk) {
                editName.setError("Update failed");
                return;
            }
        } else {
            long id = itemRepo.insertItem(name, qty);
            savedOk = id > 0;
            if (!savedOk) {
                editName.setError("Could not save item");
                return;
            }
        }

        // SMS trigger: low inventory (qty <= 2) after successful save
        if (savedOk && qty <= 2) {
            String result = maybeSendLowInventorySms(name, qty);

            // Show result on-screen AND as a toast for quick feedback
            textSmsResult.setText(result);
            Toast.makeText(this, result, Toast.LENGTH_SHORT).show();

            // User can tap Cancel/Back or Save again; or you can finish manually.
            return;
        }

        // If no SMS trigger, return to grid; InventoryActivity.onResume() refreshes
        finish();
    }

    /**
     * Returns a user-visible status string about what happened with SMS.
     * The app continues to function whether permission is granted or denied.
     */
    private String maybeSendLowInventorySms(String itemName, int qty) {
        SharedPreferences prefs = getSharedPreferences(SmsSettingsActivity.PREFS, MODE_PRIVATE);

        boolean enabled = prefs.getBoolean(SmsSettingsActivity.KEY_ENABLED, false);
        String phone = prefs.getString(SmsSettingsActivity.KEY_PHONE, "");

        if (!enabled) {
            return "Low inventory detected, but SMS alerts are OFF.";
        }

        if (TextUtils.isEmpty(phone)) {
            return "Low inventory detected, but no phone number is saved.";
        }

        if (!SmsHelper.hasSmsPermission(this)) {
            return "Low inventory detected, but SMS permission is NOT granted.";
        }

        String message = "Low inventory alert: " + itemName + " is at qty " + qty + ".";
        boolean sent = SmsHelper.sendSms(phone, message);

        if (sent) {
            return "Low inventory SMS sent.";
        } else {
            return "SMS send failed (emulator/device limitation).";
        }
    }
}