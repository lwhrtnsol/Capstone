package com.example.chrismitchellinventory;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private EditText editUsername;
    private EditText editPassword;
    private TextView textStatus;

    private UserRepository userRepo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        // Keep edge-to-edge padding behavior
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // UI hooks (IDs match your activity_main.xml)
        editUsername = findViewById(R.id.editUsername);
        editPassword = findViewById(R.id.editPassword);
        textStatus = findViewById(R.id.textStatus);

        Button buttonSignIn = findViewById(R.id.buttonSignIn);
        Button buttonCreateAccount = findViewById(R.id.buttonCreateAccount);

        // DB / repository
        userRepo = new UserRepository(this);

        buttonSignIn.setOnClickListener(v -> signIn());
        buttonCreateAccount.setOnClickListener(v -> createAccount());
    }

    private void signIn() {
        String username = safeTrim(editUsername.getText().toString());
        String password = editPassword.getText().toString(); // don't trim passwords

        if (!validateInputs(username, password)) return;

        boolean ok = userRepo.authenticate(username, password);
        if (ok) {
            textStatus.setText("Login successful.");

            Intent intent = new Intent(MainActivity.this, InventoryActivity.class);
            intent.putExtra("username", username);
            startActivity(intent);
            finish();
        } else {
            textStatus.setText("Invalid username or password.");
        }
    }

    private void createAccount() {
        String username = safeTrim(editUsername.getText().toString());
        String password = editPassword.getText().toString(); // don't trim passwords

        if (!validateInputs(username, password)) return;

        if (userRepo.userExists(username)) {
            textStatus.setText("Username already exists. Try signing in.");
            return;
        }

        long newId = userRepo.createUser(username, password);
        if (newId > 0) {
            textStatus.setText("Account created. You can sign in now.");
        } else {
            textStatus.setText("Account creation failed. Try again.");
        }
    }

    private boolean validateInputs(String username, String password) {
        if (TextUtils.isEmpty(username)) {
            textStatus.setText("Please enter a username.");
            return false;
        }
        if (TextUtils.isEmpty(password)) {
            textStatus.setText("Please enter a password.");
            return false;
        }
        if (password.length() < 6) {
            textStatus.setText("Password must be at least 6 characters.");
            return false;
        }
        return true;
    }

    private String safeTrim(String s) {
        return s == null ? "" : s.trim();
    }
}
