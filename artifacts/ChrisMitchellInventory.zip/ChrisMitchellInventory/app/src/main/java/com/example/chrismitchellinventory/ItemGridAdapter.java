package com.example.chrismitchellinventory;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class ItemGridAdapter extends BaseAdapter {

    private final Context context;
    private final LayoutInflater inflater;
    private List<Item> items = new ArrayList<>();

    public ItemGridAdapter(Context context) {
        this.context = context;
        this.inflater = LayoutInflater.from(context);
    }

    public void setItems(List<Item> newItems) {
        if (newItems == null) newItems = new ArrayList<>();
        this.items = newItems;
        notifyDataSetChanged();
    }

    public Item getItemAt(int position) {
        return items.get(position);
    }

    @Override
    public int getCount() {
        return items.size();
    }

    @Override
    public Object getItem(int position) {
        return items.get(position);
    }

    @Override
    public long getItemId(int position) {
        return items.get(position).getId();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view = convertView;

        if (view == null) {
            view = inflater.inflate(R.layout.row_inventory_item, parent, false);
        }

        TextView name = view.findViewById(R.id.textItemName);
        TextView qty = view.findViewById(R.id.textItemQty);

        Item item = items.get(position);
        name.setText(item.getName());
        qty.setText("Qty: " + item.getQuantity());

        return view;
    }
}
