package com.example.chrismitchellinventory;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;

public class PasswordUtil {

    // Generates a random 16-byte salt and returns it as a hex string
    public static String generateSalt() {
        byte[] salt = new byte[16];
        new SecureRandom().nextBytes(salt);
        return bytesToHex(salt);
    }

    // Returns SHA-256 hash of (saltHex + password) as a hex string
    public static String hashPassword(String password, String saltHex) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] input = (saltHex + password).getBytes(StandardCharsets.UTF_8);
            byte[] hash = digest.digest(input);
            return bytesToHex(hash);
        } catch (Exception e) {
            // Should not happen; return empty string if it does
            return "";
        }
    }

    // Utility: bytes -> hex string
    private static String bytesToHex(byte[] bytes) {
        StringBuilder sb = new StringBuilder(bytes.length * 2);
        for (byte b : bytes) {
            sb.append(String.format("%02x", b));
        }
        return sb.toString();
    }
}
