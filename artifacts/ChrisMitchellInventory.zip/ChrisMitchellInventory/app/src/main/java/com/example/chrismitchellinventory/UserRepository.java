package com.example.chrismitchellinventory;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

public class UserRepository {

    private final AppDatabaseHelper dbHelper;

    public UserRepository(Context context) {
        dbHelper = new AppDatabaseHelper(context.getApplicationContext());
    }

    // Checks if a username already exists in the users table
    public boolean userExists(String username) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        try (Cursor cursor = db.query(
                AppDatabaseHelper.TABLE_USERS,
                new String[]{AppDatabaseHelper.COL_USER_ID},
                AppDatabaseHelper.COL_USERNAME + "=?",
                new String[]{username},
                null, null, null
        )) {
            return cursor.moveToFirst();
        }
    }

    // Creates a new user and returns the new row ID (or -1 if failed)
    public long createUser(String username, String password) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        // Generate salt + hash so we don't store plaintext passwords
        String salt = PasswordUtil.generateSalt();
        String hash = PasswordUtil.hashPassword(password, salt);

        ContentValues values = new ContentValues();
        values.put(AppDatabaseHelper.COL_USERNAME, username);
        values.put(AppDatabaseHelper.COL_PASSWORD_HASH, hash);
        values.put(AppDatabaseHelper.COL_SALT, salt);
        values.put(AppDatabaseHelper.COL_CREATED_AT, System.currentTimeMillis());

        return db.insert(AppDatabaseHelper.TABLE_USERS, null, values);
    }

    // Returns true if the username exists and the password matches
    public boolean authenticate(String username, String password) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        try (Cursor cursor = db.query(
                AppDatabaseHelper.TABLE_USERS,
                new String[]{AppDatabaseHelper.COL_PASSWORD_HASH, AppDatabaseHelper.COL_SALT},
                AppDatabaseHelper.COL_USERNAME + "=?",
                new String[]{username},
                null, null, null
        )) {
            if (!cursor.moveToFirst()) return false;

            String storedHash = cursor.getString(0);
            String salt = cursor.getString(1);

            String inputHash = PasswordUtil.hashPassword(password, salt);
            return storedHash.equals(inputHash);
        }
    }
}
