package com.example.chrismitchellinventory;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;

public class SmsSettingsActivity extends AppCompatActivity {

    // SharedPreferences keys
    public static final String PREFS = "sms_prefs";
    public static final String KEY_ENABLED = "sms_enabled";
    public static final String KEY_PHONE = "sms_phone";

    private SwitchCompat switchEnable;
    private EditText editPhone;
    private TextView textStatus;

    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_sms_settings);

        switchEnable = findViewById(R.id.switchEnableSms);
        editPhone = findViewById(R.id.editPhoneNumber);
        textStatus = findViewById(R.id.textSmsStatus);
        Button btnRequest = findViewById(R.id.buttonRequestPermission);

        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);

        // Load saved settings
        boolean enabled = prefs.getBoolean(KEY_ENABLED, false);
        String phone = prefs.getString(KEY_PHONE, "");
        switchEnable.setChecked(enabled);
        editPhone.setText(phone);

        updatePermissionStatusText();

        // Save settings when user toggles enable
        switchEnable.setOnCheckedChangeListener((buttonView, isChecked) -> {
            prefs.edit().putBoolean(KEY_ENABLED, isChecked).apply();

            // If user tries to enable, remind them to grant permission
            if (isChecked && !SmsHelper.hasSmsPermission(this)) {
                textStatus.setText("SMS enabled, but permission is not granted yet. Tap 'Request SMS Permission'.");
            }
        });

        // Save phone number when user leaves focus
        editPhone.setOnFocusChangeListener((v, hasFocus) -> {
            if (!hasFocus) savePhone();
        });

        // Request permission button
        btnRequest.setOnClickListener(v -> {
            savePhone();
            if (!switchEnable.isChecked()) {
                textStatus.setText("Turn on 'Enable SMS alerts' first.");
                return;
            }
            if (!SmsHelper.hasSmsPermission(this)) {
                SmsHelper.requestSmsPermission(this);
            } else {
                textStatus.setText("SMS permission is already granted.");
            }
        });
    }

    private void savePhone() {
        String phone = editPhone.getText().toString().trim();
        prefs.edit().putString(KEY_PHONE, phone).apply();
    }

    private void updatePermissionStatusText() {
        if (SmsHelper.hasSmsPermission(this)) {
            textStatus.setText("SMS permission: GRANTED");
        } else {
            textStatus.setText("SMS permission: NOT granted");
        }
    }

    // Handles the user’s Allow / Deny response
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SmsHelper.REQ_SEND_SMS) {
            // Whether granted or denied, the app continues to work.
            updatePermissionStatusText();

            if (SmsHelper.hasSmsPermission(this)) {
                textStatus.setText("SMS permission granted. Alerts will send when triggers occur.");
            } else {
                textStatus.setText("SMS permission denied. App will work normally, but SMS alerts are disabled.");
                // Optional: turn off SMS enabled if denied
                prefs.edit().putBoolean(KEY_ENABLED, false).apply();
                switchEnable.setChecked(false);
            }
        }
    }
}
