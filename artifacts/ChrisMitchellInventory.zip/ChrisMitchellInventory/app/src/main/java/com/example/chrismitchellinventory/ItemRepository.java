package com.example.chrismitchellinventory;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

public class ItemRepository {

    private final AppDatabaseHelper dbHelper;

    public ItemRepository(Context context) {
        dbHelper = new AppDatabaseHelper(context.getApplicationContext());
    }

    // CREATE
    public long insertItem(String name, int quantity) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(AppDatabaseHelper.COL_ITEM_NAME, name);
        values.put(AppDatabaseHelper.COL_ITEM_QTY, quantity);
        values.put(AppDatabaseHelper.COL_ITEM_UPDATED_AT, System.currentTimeMillis());

        return db.insert(AppDatabaseHelper.TABLE_ITEMS, null, values);
    }

    // READ (all items)
    public List<Item> getAllItems() {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        List<Item> items = new ArrayList<>();

        try (Cursor cursor = db.query(
                AppDatabaseHelper.TABLE_ITEMS,
                new String[]{
                        AppDatabaseHelper.COL_ITEM_ID,
                        AppDatabaseHelper.COL_ITEM_NAME,
                        AppDatabaseHelper.COL_ITEM_QTY
                },
                null,
                null,
                null,
                null,
                AppDatabaseHelper.COL_ITEM_UPDATED_AT + " DESC"
        )) {
            while (cursor.moveToNext()) {
                long id = cursor.getLong(0);
                String name = cursor.getString(1);
                int qty = cursor.getInt(2);
                items.add(new Item(id, name, qty));
            }
        }
        return items;
    }

    // UPDATE
    public int updateItem(long itemId, String name, int quantity) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(AppDatabaseHelper.COL_ITEM_NAME, name);
        values.put(AppDatabaseHelper.COL_ITEM_QTY, quantity);
        values.put(AppDatabaseHelper.COL_ITEM_UPDATED_AT, System.currentTimeMillis());

        return db.update(
                AppDatabaseHelper.TABLE_ITEMS,
                values,
                AppDatabaseHelper.COL_ITEM_ID + "=?",
                new String[]{String.valueOf(itemId)}
        );
    }

    // DELETE
    public int deleteItem(long itemId) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        return db.delete(
                AppDatabaseHelper.TABLE_ITEMS,
                AppDatabaseHelper.COL_ITEM_ID + "=?",
                new String[]{String.valueOf(itemId)}
        );
    }
}
