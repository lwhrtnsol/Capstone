package com.example.chrismitchellinventory;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.GridView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class InventoryActivity extends AppCompatActivity {

    private GridView gridItems;
    private TextView textHeader;
    private FloatingActionButton fabAdd;
    private Button buttonSmsSettings;

    private ItemRepository itemRepo;
    private ItemGridAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_inventory);

        textHeader = findViewById(R.id.textHeader);
        gridItems = findViewById(R.id.gridItems);
        fabAdd = findViewById(R.id.fabAdd);
        buttonSmsSettings = findViewById(R.id.buttonSmsSettings);

        // Open SMS Settings screen
        buttonSmsSettings.setOnClickListener(v -> {
            Intent intent = new Intent(InventoryActivity.this, SmsSettingsActivity.class);
            startActivity(intent);
        });

        // Optional: show who is logged in
        String username = getIntent().getStringExtra("username");
        if (username != null && !username.isEmpty()) {
            textHeader.setText("Inventory - " + username);
        }

        itemRepo = new ItemRepository(this);

        adapter = new ItemGridAdapter(this);
        gridItems.setAdapter(adapter);

        // Tap an item to edit it (UPDATE)
        gridItems.setOnItemClickListener((parent, view, position, id) -> {
            Item selected = adapter.getItemAt(position);

            Intent intent = new Intent(InventoryActivity.this, AddEditItemActivity.class);
            intent.putExtra("mode", "edit");
            intent.putExtra("item_id", selected.getId());
            intent.putExtra("name", selected.getName());
            intent.putExtra("qty", selected.getQuantity());
            startActivity(intent);
        });

        // Long-press an item to delete it (DELETE)
        gridItems.setOnItemLongClickListener((parent, view, position, id) -> {
            Item selected = adapter.getItemAt(position);

            new AlertDialog.Builder(InventoryActivity.this)
                    .setTitle("Delete item?")
                    .setMessage("Delete \"" + selected.getName() + "\"?")
                    .setPositiveButton("Delete", (dialog, which) -> {
                        itemRepo.deleteItem(selected.getId());
                        refreshGrid();
                    })
                    .setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss())
                    .show();

            return true; // consume the long-click
        });

        // Add button opens Add/Edit screen
        fabAdd.setOnClickListener(v -> {
            Intent intent = new Intent(InventoryActivity.this, AddEditItemActivity.class);
            startActivity(intent);
        });

        // Load items now
        refreshGrid();
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Refresh grid after returning from Add/Edit screen
        refreshGrid();
    }

    private void refreshGrid() {
        adapter.setItems(itemRepo.getAllItems());
    }
}