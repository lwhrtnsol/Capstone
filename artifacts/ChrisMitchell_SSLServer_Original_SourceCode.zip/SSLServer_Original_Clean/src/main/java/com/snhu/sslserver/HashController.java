package com.snhu.sslserver;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 * Simple controller that returns a SHA-256 checksum of either a provided
 * string or a default sample string, rendered as hex. This satisfies
 * the assignment requirement for 'https://localhost:8443/hash'.
 */
@RestController
public class HashController {

    private static final String DEFAULT_DATA = "Hello World Check Sum!";

    @GetMapping({"/hash"})
    public String hash(@RequestParam(name = "data", required = false) String data) throws NoSuchAlgorithmException {
        String name = "Chris Mitchell"; // customize if needed
        String payload = (data == null || data.isEmpty()) ? DEFAULT_DATA : data;

        String hashHex = sha256Hex(payload);

        StringBuilder sb = new StringBuilder();
        sb.append("<html><body>");
        sb.append("<h2>Artemis Financial — Checksum Verification</h2>");
        sb.append("<p><strong>Name:</strong> ").append(name).append("</p>");
        sb.append("<p><strong>Input:</strong> ").append(escapeHtml(payload)).append("</p>");
        sb.append("<p><strong>SHA‑256 Hash:</strong> ").append(hashHex).append("</p>");
        sb.append("<p>Try your own string by visiting <code>/hash?data=Your+Text+Here</code>.</p>");
        sb.append("</body></html>");
        return sb.toString();
    }

    private static String sha256Hex(String s) throws NoSuchAlgorithmException {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        byte[] bytes = digest.digest(s.getBytes(StandardCharsets.UTF_8));
        StringBuilder hex = new StringBuilder();
        for (byte b : bytes) {
            hex.append(String.format("%02x", b));
        }
        return hex.toString();
    }

    // Very small HTML escaper for demo purposes
    private static String escapeHtml(String s) {
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
    }
}
