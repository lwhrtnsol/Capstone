import { Routes } from '@angular/router';
import { TripListComponent } from './trip-list/trip-list';
import { AddTripComponent } from './add-trip/add-trip';
import { EditTripComponent } from './edit-trip/edit-trip';
import { LoginComponent } from './login/login';

export const routes: Routes = [
  { path: '', component: TripListComponent },
  { path: 'trip-info', component: TripListComponent },
  { path: 'travel-agent', component: TripListComponent },
  { path: 'add-trip', component: AddTripComponent },
  { path: 'edit-trip', component: EditTripComponent },
  { path: 'login', component: LoginComponent }
];
