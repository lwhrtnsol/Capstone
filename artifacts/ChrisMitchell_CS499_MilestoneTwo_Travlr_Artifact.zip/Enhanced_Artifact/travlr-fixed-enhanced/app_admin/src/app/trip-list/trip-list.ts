import { CommonModule } from '@angular/common';
import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Trip } from '../models/trip';
import { TripCardComponent } from '../trip-card/trip-card';
import { TripDataService } from '../services/trip-data';

@Component({
  selector: 'app-trip-list',
  standalone: true,
  imports: [CommonModule, FormsModule, TripCardComponent],
  templateUrl: './trip-list.html',
  styleUrl: './trip-list.css'
})
export class TripListComponent implements OnInit {
  trips: Trip[] = [];

  formData: Trip = {
    code: '',
    name: '',
    length: '',
    start: '',
    resort: '',
    perPerson: '',
    image: '',
    description: ''
  };

  selectedTripCode = '';
  isEditing = false;

  constructor(
    private tripDataService: TripDataService,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    this.loadTrips();
  }

  loadTrips(): void {
    this.tripDataService.getTrips().subscribe((data: Trip[]) => {
      this.trips = data;
      this.cdr.detectChanges();
    });
  }

  resetForm(): void {
    this.formData = {
      code: '',
      name: '',
      length: '',
      start: '',
      resort: '',
      perPerson: '',
      image: '',
      description: ''
    };
    this.selectedTripCode = '';
    this.isEditing = false;
  }

  onSubmit(): void {
    if (this.isEditing) {
      this.tripDataService.updateTrip(this.formData).subscribe(() => {
        this.resetForm();
        this.loadTrips();
      });
    } else {
      this.tripDataService.addTrip(this.formData).subscribe(() => {
        this.resetForm();
        this.loadTrips();
      });
    }
  }

  onEditTrip(trip: Trip): void {
    this.formData = { ...trip };
    this.selectedTripCode = trip.code;
    this.isEditing = true;
  }

  onDeleteTrip(code: string): void {
    this.tripDataService.deleteTrip(code).subscribe(() => {
      this.loadTrips();
    });
  }
}
