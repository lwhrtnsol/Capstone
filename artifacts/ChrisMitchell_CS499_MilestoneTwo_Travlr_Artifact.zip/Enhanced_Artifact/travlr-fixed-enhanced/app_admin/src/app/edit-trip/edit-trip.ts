import { CommonModule } from '@angular/common';
import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { Trip } from '../models/trip';
import { TripDataService } from '../services/trip-data';

@Component({
  selector: 'app-edit-trip',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './edit-trip.html',
  styleUrl: './edit-trip.css'
})
export class EditTripComponent implements OnInit {
  trip: Trip = {
    code: '',
    name: '',
    length: '',
    start: '',
    resort: '',
    perPerson: '',
    image: '',
    description: ''
  };

  constructor(
    private tripDataService: TripDataService,
    private router: Router,
    private cdr: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    const tripCode = localStorage.getItem('tripCode');

    if (tripCode) {
      this.tripDataService.getTrip(tripCode).subscribe({
        next: (value: any) => {
          this.trip = {
            code: value.code || '',
            name: value.name || '',
            length: value.length || '',
            start: value.start || '',
            resort: value.resort || '',
            perPerson: value.perPerson || '',
            image: value.image || '',
            description: value.description || ''
          };

          this.cdr.detectChanges();
        },
        error: (err: any) => {
          console.error('Error loading trip details', err);
        }
      });
    }
  }

  onSubmit(): void {
    this.tripDataService.updateTrip(this.trip).subscribe({
      next: () => {
        this.router.navigate(['']);
      },
      error: (err: any) => {
        console.error('Error updating trip', err);
      }
    });
  }
}