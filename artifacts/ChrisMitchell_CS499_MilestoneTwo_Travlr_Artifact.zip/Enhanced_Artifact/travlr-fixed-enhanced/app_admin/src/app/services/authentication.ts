import { Inject, Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, tap } from 'rxjs';
import { AuthResponse } from '../models/auth-response';
import { BROWSER_STORAGE } from '../storage';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {
  private apiBaseUrl = 'http://localhost:3000/api';

  constructor(
    private http: HttpClient,
    @Inject(BROWSER_STORAGE) private storage: Storage
  ) {}

  public register(user: { name: string; email: string; password: string }): Observable<AuthResponse> {
    return this.http.post<AuthResponse>(`${this.apiBaseUrl}/register`, user).pipe(
      tap((authResponse: AuthResponse) => this.saveToken(authResponse.token))
    );
  }

  public login(user: { email: string; password: string }): Observable<AuthResponse> {
    return this.http.post<AuthResponse>(`${this.apiBaseUrl}/login`, user).pipe(
      tap((authResponse: AuthResponse) => this.saveToken(authResponse.token))
    );
  }

  public saveToken(token: string): void {
    this.storage.setItem('travlr-token', token);
  }

  public getToken(): string {
    return this.storage.getItem('travlr-token') || '';
  }

  public logout(): void {
    this.storage.removeItem('travlr-token');
  }

  public isLoggedIn(): boolean {
    const token = this.getToken();
    return token !== '';
  }
}