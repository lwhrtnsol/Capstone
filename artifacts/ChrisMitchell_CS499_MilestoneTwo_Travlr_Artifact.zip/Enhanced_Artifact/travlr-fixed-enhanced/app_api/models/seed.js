const mongoose = require('mongoose');
require('./db');

const Trip = mongoose.model('trips');

const seedTrips = [
  {
    code: 'BCS',
    name: 'Beachy Cabo Escape',
    length: '7 nights / 8 days',
    start: 'Los Angeles',
    resort: 'Cabo San Lucas Resort',
    perPerson: '$1299',
    image: 'sea-sound.jpg',
    description: 'Relax on the beaches of Cabo San Lucas with ocean views, sunshine, and resort amenities.'
  },
  {
    code: 'NYS',
    name: 'New York City Adventure',
    length: '4 nights / 5 days',
    start: 'New York',
    resort: 'Manhattan Grand Hotel',
    perPerson: '$999',
    image: 'deluxe.jpg',
    description: 'Experience the energy of New York City with famous landmarks, dining, and entertainment.'
  },
  {
    code: 'EUR',
    name: 'European Explorer',
    length: '10 nights / 11 days',
    start: 'London',
    resort: 'Continental Tour Package',
    perPerson: '$2499',
    image: 'reef1.jpg',
    description: 'Travel across Europe and enjoy culture, history, and unforgettable sightseeing experiences.'
  }
];

Trip.deleteMany({})
  .then(() => Trip.insertMany(seedTrips))
  .then(() => {
    console.log('Database seeded successfully');
    mongoose.connection.close();
  })
  .catch((err) => {
    console.log(err);
    mongoose.connection.close();
  });