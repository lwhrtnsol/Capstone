const mongoose = require('mongoose');

const tripSchema = new mongoose.Schema({
  code: {
    type: String,
    required: [true, 'Trip code is required.'],
    trim: true,
    unique: true,
    minlength: [2, 'Trip code must contain at least 2 characters.'],
    maxlength: [10, 'Trip code cannot exceed 10 characters.'],
    match: [/^[A-Za-z0-9-]+$/, 'Trip code may only contain letters, numbers, and hyphens.']
  },
  name: {
    type: String,
    required: [true, 'Trip name is required.'],
    trim: true,
    minlength: [2, 'Trip name must contain at least 2 characters.'],
    maxlength: [100, 'Trip name cannot exceed 100 characters.']
  },
  length: {
    type: String,
    required: [true, 'Trip length is required.'],
    trim: true
  },
  start: {
    type: String,
    required: [true, 'Start date is required.'],
    trim: true,
    validate: {
      validator: function (value) {
        return !Number.isNaN(Date.parse(value));
      },
      message: 'Start date must be a valid date.'
    }
  },
  resort: {
    type: String,
    required: [true, 'Resort is required.'],
    trim: true,
    minlength: [2, 'Resort must contain at least 2 characters.'],
    maxlength: [100, 'Resort cannot exceed 100 characters.']
  },
  perPerson: {
    type: String,
    required: [true, 'Price per person is required.'],
    trim: true,
    validate: {
      validator: function (value) {
        const price = Number(String(value).replace(/[$,]/g, ''));
        return Number.isFinite(price) && price >= 0;
      },
      message: 'Price per person must be a valid non-negative amount.'
    }
  },
  image: {
    type: String,
    required: [true, 'Image filename is required.'],
    trim: true
  },
  description: {
    type: String,
    required: [true, 'Trip description is required.'],
    trim: true,
    minlength: [10, 'Trip description must contain at least 10 characters.'],
    maxlength: [1000, 'Trip description cannot exceed 1000 characters.']
  }
});

mongoose.model('trips', tripSchema);