const mongoose = require('mongoose');

const dbURI = process.env.MONGODB_URI;

if (!dbURI) {
  console.error('Database connection failed: MONGODB_URI is not defined.');
  process.exit(1);
}

mongoose.connect(dbURI).catch((err) => {
  console.error('Initial Mongoose connection error:', err.message);
});

mongoose.connection.on('connected', () => {
  console.log('Mongoose connected to the Travlr database.');
});

mongoose.connection.on('error', (err) => {
  console.error('Mongoose connection error:', err.message);
});

mongoose.connection.on('disconnected', () => {
  console.log('Mongoose disconnected.');
});

process.once('SIGINT', async () => {
  await mongoose.connection.close();
  console.log('Mongoose disconnected through application termination.');
  process.exit(0);
});

require('./travlr');
require('./users');