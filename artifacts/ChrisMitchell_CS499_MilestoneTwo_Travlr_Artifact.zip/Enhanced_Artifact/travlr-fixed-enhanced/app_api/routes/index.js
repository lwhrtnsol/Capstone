require('dotenv').config();

const express = require('express');
const router = express.Router();
const { expressjwt: jwt } = require('express-jwt');
const ctrlTrips = require('../controllers/trips');
const ctrlAuth = require('../controllers/authentication');

const jwtSecret = process.env.JWT_SECRET;

if (!jwtSecret) {
  throw new Error('JWT_SECRET is not defined in the environment variables.');
}

const auth = jwt({
  secret: jwtSecret,
  userProperty: 'payload',
  algorithms: ['HS256']
});

router.post('/register', ctrlAuth.register);
router.post('/login', ctrlAuth.login);

router
  .route('/trips')
  .get(ctrlTrips.tripsList)
  .post(auth, ctrlTrips.tripsAddTrip);

router
  .route('/trips/:tripCode')
  .get(ctrlTrips.tripsFindCode)
  .put(auth, ctrlTrips.tripsUpdateTrip)
  .delete(auth, ctrlTrips.tripsDeleteTrip);

module.exports = router;