const mongoose = require('mongoose');
const Trip = mongoose.model('trips');

/**
 * Returns a consistent error response for duplicate trip codes,
 * validation failures, and unexpected server errors.
 */
const handleTripError = (res, err, defaultStatus = 500) => {
  if (err && err.code === 11000) {
    return res.status(409).json({
      message: 'A trip with this trip code already exists.'
    });
  }

  if (err && err.name === 'ValidationError') {
    const errors = Object.values(err.errors).map((error) => error.message);

    return res.status(400).json({
      message: 'Trip validation failed.',
      errors
    });
  }

  console.error(err);

  return res.status(defaultStatus).json({
    message: 'Unable to process the trip request.'
  });
};

/**
 * Checks that the trip code URL parameter contains a usable value.
 */
const isValidTripCode = (tripCode) => {
  return typeof tripCode === 'string' && tripCode.trim().length > 0;
};

/**
 * Builds a clean trip object from request body data.
 */
const buildTripData = (body = {}) => ({
  code: typeof body.code === 'string' ? body.code.trim() : body.code,
  name: typeof body.name === 'string' ? body.name.trim() : body.name,
  length: typeof body.length === 'string' ? body.length.trim() : body.length,
  start: typeof body.start === 'string' ? body.start.trim() : body.start,
  resort: typeof body.resort === 'string' ? body.resort.trim() : body.resort,
  perPerson: typeof body.perPerson === 'string' ? body.perPerson.trim() : body.perPerson,
  image: typeof body.image === 'string' ? body.image.trim() : body.image,
  description: typeof body.description === 'string'
    ? body.description.trim()
    : body.description
});

const tripsList = async (req, res) => {
  try {
    const trips = await Trip.find({}).sort({ start: 1 }).exec();
    return res.status(200).json(trips);
  } catch (err) {
    return handleTripError(res, err);
  }
};

const tripsFindCode = async (req, res) => {
  const tripCode = req.params.tripCode;

  if (!isValidTripCode(tripCode)) {
    return res.status(400).json({
      message: 'A valid trip code is required.'
    });
  }

  try {
    const trip = await Trip.findOne({ code: tripCode.trim() }).exec();

    if (!trip) {
      return res.status(404).json({
        message: 'Trip not found.'
      });
    }

    return res.status(200).json(trip);
  } catch (err) {
    return handleTripError(res, err);
  }
};

const tripsAddTrip = async (req, res) => {
  try {
    const tripData = buildTripData(req.body);
    const trip = await Trip.create(tripData);

    return res.status(201).json(trip);
  } catch (err) {
    return handleTripError(res, err, 400);
  }
};

const tripsUpdateTrip = async (req, res) => {
  const tripCode = req.params.tripCode;

  if (!isValidTripCode(tripCode)) {
    return res.status(400).json({
      message: 'A valid trip code is required.'
    });
  }

  try {
    const tripData = buildTripData(req.body);

    // Do not allow the trip identifier to be changed during an update.
    delete tripData.code;

    const trip = await Trip.findOneAndUpdate(
      { code: tripCode.trim() },
      tripData,
      {
        new: true,
        runValidators: true
      }
    ).exec();

    if (!trip) {
      return res.status(404).json({
        message: 'Trip not found.'
      });
    }

    return res.status(200).json(trip);
  } catch (err) {
    return handleTripError(res, err, 400);
  }
};

const tripsDeleteTrip = async (req, res) => {
  const tripCode = req.params.tripCode;

  if (!isValidTripCode(tripCode)) {
    return res.status(400).json({
      message: 'A valid trip code is required.'
    });
  }

  try {
    const trip = await Trip.findOneAndDelete({
      code: tripCode.trim()
    }).exec();

    if (!trip) {
      return res.status(404).json({
        message: 'Trip not found.'
      });
    }

    return res.status(204).send();
  } catch (err) {
    return handleTripError(res, err);
  }
};

module.exports = {
  tripsList,
  tripsFindCode,
  tripsAddTrip,
  tripsUpdateTrip,
  tripsDeleteTrip
};