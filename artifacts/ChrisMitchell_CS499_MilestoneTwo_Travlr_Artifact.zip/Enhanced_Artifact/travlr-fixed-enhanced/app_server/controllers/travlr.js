const axios = require('axios');

const travel = async (req, res) => {
  try {
    const response = await axios.get('http://localhost:3000/api/trips');

    res.render('travel', {
      title: 'Travlr Getaways',
      pageHeader: {
        title: 'Travlr Getaways',
        strapline: 'Where will your next adventure take you?'
      },
      trips: response.data
    });
  } catch (err) {
    console.log(err);
    res.status(500).send('Error retrieving trips');
  }
};

module.exports = {
  travel
};
