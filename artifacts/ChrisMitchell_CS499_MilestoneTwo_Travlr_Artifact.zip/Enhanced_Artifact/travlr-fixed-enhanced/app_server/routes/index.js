var express = require('express');
var router = express.Router();
const ctrlTravlr = require('../controllers/travlr');

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});

router.get('/travel', ctrlTravlr.travel);

module.exports = router;
