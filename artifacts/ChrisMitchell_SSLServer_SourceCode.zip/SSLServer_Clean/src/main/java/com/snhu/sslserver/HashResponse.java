package com.snhu.sslserver;

/**
 * Response object returned by the hash endpoint.
 */
public class HashResponse {

    private final String name;
    private final String input;
    private final String algorithm;
    private final String hash;
    private final int inputLength;

    public HashResponse(String name, String input, String algorithm, String hash, int inputLength) {
        this.name = name;
        this.input = input;
        this.algorithm = algorithm;
        this.hash = hash;
        this.inputLength = inputLength;
    }

    public String getName() {
        return name;
    }

    public String getInput() {
        return input;
    }

    public String getAlgorithm() {
        return algorithm;
    }

    public String getHash() {
        return hash;
    }

    public int getInputLength() {
        return inputLength;
    }
}