package com.snhu.sslserver;

import org.springframework.stereotype.Service;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 * Service class that contains the checksum algorithm.
 * This class demonstrates algorithmic processing through input validation,
 * byte-array hashing, and hexadecimal conversion.
 */
@Service
public class HashService {

    private static final String DEFAULT_DATA = "Hello World Check Sum!";
    private static final String ALGORITHM = "SHA-256";
    private static final int MAX_INPUT_LENGTH = 10000;
    private static final char[] HEX_VALUES = "0123456789abcdef".toCharArray();

    public HashResponse generateHash(String data) {
        String payload = normalizeInput(data);
        String hashValue = sha256Hex(payload);

        return new HashResponse(
                "Chris Mitchell",
                payload,
                ALGORITHM,
                hashValue,
                payload.length()
        );
    }

    private String normalizeInput(String data) {
        if (data == null) {
            return DEFAULT_DATA;
        }

        String trimmedData = data.trim();

        if (trimmedData.isEmpty()) {
            throw new IllegalArgumentException("Input cannot be blank.");
        }

        if (trimmedData.length() > MAX_INPUT_LENGTH) {
            throw new IllegalArgumentException("Input cannot exceed " + MAX_INPUT_LENGTH + " characters.");
        }

        return trimmedData;
    }

    public String sha256Hex(String value) {
        try {
            MessageDigest digest = MessageDigest.getInstance(ALGORITHM);
            byte[] hashBytes = digest.digest(value.getBytes(StandardCharsets.UTF_8));
            return bytesToHex(hashBytes);
        } catch (NoSuchAlgorithmException ex) {
            throw new IllegalStateException("Required hashing algorithm is not available.", ex);
        }
    }

    private String bytesToHex(byte[] bytes) {
        char[] hexCharacters = new char[bytes.length * 2];

        for (int i = 0; i < bytes.length; i++) {
            int value = bytes[i] & 0xFF;
            hexCharacters[i * 2] = HEX_VALUES[value >>> 4];
            hexCharacters[i * 2 + 1] = HEX_VALUES[value & 0x0F];
        }

        return new String(hexCharacters);
    }
}