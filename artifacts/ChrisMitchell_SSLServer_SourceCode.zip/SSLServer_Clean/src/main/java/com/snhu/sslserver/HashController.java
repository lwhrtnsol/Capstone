package com.snhu.sslserver;

import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Controller for checksum requests.
 * The controller handles the web request and delegates the hashing algorithm
 * to HashService so the algorithmic logic is easier to test and maintain.
 */
@RestController
public class HashController {

    private final HashService hashService;

    public HashController(HashService hashService) {
        this.hashService = hashService;
    }

    @GetMapping(value = "/hash", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> hash(@RequestParam(name = "data", required = false) String data) {
        try {
            HashResponse response = hashService.generateHash(data);
            return ResponseEntity.ok(response);
        } catch (IllegalArgumentException ex) {
            Map<String, String> errorResponse = new LinkedHashMap<>();
            errorResponse.put("error", ex.getMessage());
            return ResponseEntity.badRequest().body(errorResponse);
        }
    }
}
